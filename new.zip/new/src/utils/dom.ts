export const getElementByClassName = (className: string) =>
    document.getElementsByClassName(className);
