export const actionTypes = {
  STOREIMAGE: 'STOREIMAGE',
  SCREENSHOT:'SCREENSHOT'
};
